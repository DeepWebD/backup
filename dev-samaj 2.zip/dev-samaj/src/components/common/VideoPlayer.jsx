/* eslint-disable react/prop-types */
import React, { useRef } from "react";
import VideoBg from "../../../public/videoBg.mp4";

const VideoPlayer = ({videoUrl}) => {
  const videoRef = useRef(null);
console.log("videoUrl", videoUrl);
  return (
    <div className="w-full h-full flex flex-col items-center">
      <video
        ref={videoRef}
        controls
        autoPlay
        loop
        className="w-full h-full border flex items-center rounded-lg object-cover"
      >
        <source src={videoUrl} type="video/mp4" />
        Your browser does not support the video tag.
      </video>
    </div>
  );
};

export default VideoPlayer;
