export const vidoes = [
  {
    title: "Believe in Yourself",
    url: "https://www.youtube.com/watch?v=ZXsQAXx_ao0",
  },
  {
    title: "Never Give Up",
    url: "https://www.youtube.com/watch?v=mgmVOuLgFB0",
  },
  {
    title: "The Power of Positivity",
    url: "https://www.youtube.com/watch?v=GZ7dG4s5n4I",
  },
  {
    title: "Overcoming Challenges",
    url: "https://www.youtube.com/watch?v=2Gg8eT3I1fA",
  },
  {
    title: "Stay Focused",
    url: "https://www.youtube.com/watch?v=1n3g9Q8M3cQ",
  },
  {
    title: "Embrace Failure",
    url: "https://www.youtube.com/watch?v=H14bBuluwB8",
  },
  {
    title: "Dream Big",
    url: "https://www.youtube.com/watch?v=QJncFirhjPg",
  },
  {
    title: "Push Your Limits",
    url: "https://www.youtube.com/watch?v=mgmVOuLgFB0",
  },
  {
    title: "Stay Hungry",
    url: "https://www.youtube.com/watch?v=KdXAUst8bdo",
  },
  {
    title: "Take Action",
    url: "https://www.youtube.com/watch?v=wnHW6o8WMas",
  },
];
