export const USER_ROLE = {
  STUDENT: "student",
  TEACHER: "teacher",
  ADMIN: "admin",
  MASTER_ADMIN: " master_admin",
};
