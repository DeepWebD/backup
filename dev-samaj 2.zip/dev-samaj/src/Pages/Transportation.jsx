import React from "react";

const Transportation = () => {
  return (
    <div className="flex h-[80vh] justify-center flex-col items-center p-2  mt-[80px] bg-slate-300 font-bold text-4xl text-slate-200">
      Transportation
    </div>
  );
};

export default Transportation;
